create database RailwayReservation;

USE RailwayReservation;
CREATE TABLE Users (
    UserId INT PRIMARY KEY IDENTITY(1,1),
    Username NVARCHAR(50) NOT NULL,
    Password NVARCHAR(50) NOT NULL,
    FullName NVARCHAR(100),
    Email NVARCHAR(100)
);

CREATE TABLE Trains (
    TrainId INT PRIMARY KEY IDENTITY(1,1),
    TrainName NVARCHAR(100) NOT NULL,
    Source NVARCHAR(100) NOT NULL,
    Destination NVARCHAR(100) NOT NULL,
    DepartureTime DATETIME NOT NULL,
    ArrivalTime DATETIME NOT NULL,
    Fare DECIMAL(10, 2) NOT NULL
);

CREATE TABLE Reservations (
    ReservationId INT PRIMARY KEY IDENTITY(1,1),
    UserId INT FOREIGN KEY REFERENCES Users(UserId),
    TrainId INT FOREIGN KEY REFERENCES Trains(TrainId),
    PNR NVARCHAR(20) NOT NULL UNIQUE,
    ReservationDate DATETIME NOT NULL,
    Class NVARCHAR(50),
    Status NVARCHAR(50)
);

CREATE TABLE Passengers (
    PassengerId INT PRIMARY KEY IDENTITY(1,1),
    ReservationId INT FOREIGN KEY REFERENCES Reservations(ReservationId),
    Name NVARCHAR(100) NOT NULL,
    Gender NVARCHAR(10),
    Age INT,
    Address NVARCHAR(200)
);

-- Insert into Users table
INSERT INTO Users (Username, Password, FullName, Email) VALUES 
('raj123', 'password123', 'Rajesh Kumar', 'rajesh.kumar@example.com'),
('anita456', 'password456', 'Anita Sharma', 'anita.sharma@example.com'),
('vikas789', 'password789', 'Vikas Gupta', 'vikas.gupta@example.com');

-- Insert into Trains table
INSERT INTO Trains (TrainName, Source, Destination, DepartureTime, ArrivalTime, Fare) VALUES 
('Rajdhani Express', 'Mumbai', 'Delhi', '2024-11-01 08:00:00', '2024-11-01 20:00:00', 2500.00),
('Shatabdi Express', 'Chennai', 'Bangalore', '2024-11-02 06:00:00', '2024-11-02 12:00:00', 1500.00),
('Duronto Express', 'Kolkata', 'Mumbai', '2024-11-03 14:00:00', '2024-11-04 10:00:00', 3000.00);

-- Insert into Reservations table
INSERT INTO Reservations (UserId, TrainId, PNR, ReservationDate, Class, Status) VALUES 
(1, 1, 'PNR1234567890', '2024-10-28 10:00:00', 'First Class', 'Confirmed'),
(2, 2, 'PNR0987654321', '2024-10-28 11:00:00', 'Second Class', 'Confirmed'),
(3, 3, 'PNR1122334455', '2024-10-28 12:00:00', 'Sleeper Class', 'Confirmed');

-- Insert into Passengers table
INSERT INTO Passengers (ReservationId, Name, Gender, Age, Address) VALUES 
(1, 'Rajesh Kumar', 'Male', 35, '123, MG Road, Mumbai'),
(2, 'Anita Sharma', 'Female', 28, '456, Anna Salai, Chennai'),
(3, 'Vikas Gupta', 'Male', 40, '789, Park Street, Kolkata');

select * from Users;
select * from Trains;
select * from Reservations;
Select * from Passengers;
drop Database RailwayReservation;
