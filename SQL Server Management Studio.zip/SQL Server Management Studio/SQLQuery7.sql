use RailwayReservationDB
CREATE TABLE Users (
    UserId INT PRIMARY KEY IDENTITY,
    Username NVARCHAR(50) NOT NULL,
    Password NVARCHAR(50) NOT NULL,
    Email NVARCHAR(50) NOT NULL
);

CREATE TABLE Trains (
    TrainId INT PRIMARY KEY IDENTITY,
    TrainName NVARCHAR(50) NOT NULL,
    Source NVARCHAR(50) NOT NULL,
    Destination NVARCHAR(50) NOT NULL,
    DepartureTime DATETIME NOT NULL,
    ArrivalTime DATETIME NOT NULL
);

CREATE TABLE Reservations (
    ReservationId INT PRIMARY KEY IDENTITY,
    UserId INT FOREIGN KEY REFERENCES Users(UserId),
    TrainId INT FOREIGN KEY REFERENCES Trains(TrainId),
    ReservationDate DATETIME NOT NULL,
    Status NVARCHAR(20) NOT NULL
);