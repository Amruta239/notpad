use StudentDB;
select * from Students;
drop Database DataBaseFirstDemo;