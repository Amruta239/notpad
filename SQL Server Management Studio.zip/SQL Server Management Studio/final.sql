CREATE DATABASE RailwayReservationSystem;

USE RailwayReservationSystem;
 
CREATE TABLE Passengers 

(    

PassengerID INT PRIMARY KEY IDENTITY,    

Name NVARCHAR(100),    

Gender NVARCHAR(10),    

Age INT,    

Address NVARCHAR(200),    

Username NVARCHAR(50),    

Password NVARCHAR(50)

);
 
CREATE TABLE Trains (

    TrainId INT PRIMARY KEY IDENTITY(1,1),

    TrainName NVARCHAR(100) NOT NULL,

    Source NVARCHAR(100) NOT NULL,

    Destination NVARCHAR(100) NOT NULL,

    DepartureTime DATETIME NOT NULL,

    ArrivalTime DATETIME NOT NULL,

    TotalSeats INT NOT NULL,

    AvailableSeats INT NOT NULL,

    Fare DECIMAL(10, 2) NOT NULL

);
 
INSERT INTO Trains (TrainName, Source, Destination, DepartureTime, ArrivalTime, TotalSeats, AvailableSeats, Fare)

VALUES 

('Rajdhani Express', 'Mumbai', 'Delhi', '2024-11-01 08:00:00', '2024-11-01 20:00:00', 500, 450, 2500.00),

('Shatabdi Express', 'Chennai', 'Bangalore', '2024-11-02 06:00:00', '2024-11-02 10:00:00', 300, 280, 1500.00),

('Duronto Express', 'Kolkata', 'Mumbai', '2024-11-03 07:00:00', '2024-11-04 11:00:00', 400, 350, 3000.00),

('Garib Rath', 'Delhi', 'Kolkata', '2024-11-04 09:00:00', '2024-11-05 12:00:00', 600, 500, 2000.00),

('Jan Shatabdi', 'Mumbai', 'Goa', '2024-11-05 05:00:00', '2024-11-05 13:00:00', 350, 320, 1200.00),

('Tejas Express', 'Mumbai', 'Ahmedabad', '2024-11-06 07:00:00', '2024-11-06 13:00:00', 400, 380, 1800.00),

('Humsafar Express', 'Bangalore', 'Delhi', '2024-11-07 10:00:00', '2024-11-08 18:00:00', 500, 450, 2200.00),

('Vande Bharat Express', 'Delhi', 'Varanasi', '2024-11-08 06:00:00', '2024-11-08 14:00:00', 450, 400, 2000.00),

('Maharaja Express', 'Mumbai', 'Jaipur', '2024-11-09 08:00:00', '2024-11-09 20:00:00', 200, 180, 5000.00),

('Deccan Queen', 'Mumbai', 'Pune', '2024-11-10 07:00:00', '2024-11-10 11:00:00', 300, 280, 1000.00),

('Karnataka Express', 'Bangalore', 'Delhi', '2024-11-11 09:00:00', '2024-11-12 18:00:00', 600, 550, 2500.00),

('Gatimaan Express', 'Delhi', 'Agra', '2024-11-12 08:00:00', '2024-11-12 10:00:00', 200, 180, 1500.00),

('Konkan Kanya Express', 'Mumbai', 'Goa', '2024-11-13 06:00:00', '2024-11-13 14:00:00', 350, 320, 1300.00),

('Mandovi Express', 'Mumbai', 'Goa', '2024-11-14 07:00:00', '2024-11-14 15:00:00', 350, 300, 1200.00),

('Howrah Mail', 'Chennai', 'Kolkata', '2024-11-15 08:00:00', '2024-11-16 12:00:00', 500, 450, 2200.00),

('Punjab Mail', 'Mumbai', 'Firozpur', '2024-11-16 07:00:00', '2024-11-17 15:00:00', 400, 350, 2000.00),

('Goa Express', 'Delhi', 'Goa', '2024-11-17 06:00:00', '2024-11-18 14:00:00', 450, 400, 2500.00),

('Kerala Express', 'Delhi', 'Trivandrum', '2024-11-18 09:00:00', '2024-11-19 18:00:00', 600, 550, 3000.00),

('Tamil Nadu Express', 'Delhi', 'Chennai', '2024-11-19 10:00:00', '2024-11-20 20:00:00', 500, 450, 2800.00),

('Jhelum Express', 'Pune', 'Jammu', '2024-11-20 08:00:00', '2024-11-21 18:00:00', 400, 350, 2500.00),

('Ajmer Shatabdi', 'Delhi', 'Ajmer', '2024-11-21 06:00:00', '2024-11-21 12:00:00', 300, 280, 1500.00),

('Lucknow Mail', 'Delhi', 'Lucknow', '2024-11-22 08:00:00', '2024-11-22 16:00:00', 400, 350, 1800.00),

('Sealdah Rajdhani', 'Delhi', 'Kolkata', '2024-11-23 07:00:00', '2024-11-23 19:00:00', 500, 450, 2500.00),

('Netravati Express', 'Mumbai', 'Trivandrum', '2024-11-24 06:00:00', '2024-11-25 12:00:00', 450, 400, 2700.00),

('Chennai Express', 'Mumbai', 'Chennai', '2024-11-25 08:00:00', '2024-11-26 10:00:00', 500, 450, 2300.00);
 
select * from Trains;

CREATE TABLE Reservations (

    ReservationId INT PRIMARY KEY IDENTITY(1,1),

    PassengerID INT FOREIGN KEY REFERENCES Passengers(PassengerID),

    TrainId INT FOREIGN KEY REFERENCES Trains(TrainId),

    PassengerName NVARCHAR(100) NOT NULL,

    Gender NVARCHAR(10) NOT NULL,

    Age INT NOT NULL,

	CreditNo INT, 

	BankName VARCHAR(40), 

	Quota VARCHAR(20),

    PNR NVARCHAR(20) NOT NULL UNIQUE,

    ReservationDate DATETIME NOT NULL,

    TicketStatus NVARCHAR(20) NOT NULL check (TicketStatus IN('Reserved','Cancelled'))

);
 

-- Update the fare in the Trains table

UPDATE Trains

SET Fare = @Fare

WHERE TrainId = @TrainId;


use RailwayReservationSystem;
ALTER TABLE Reservations
ADD Source NVARCHAR(100),
    Destination NVARCHAR(100),
    Fare DECIMAL(10, 2);

use RailwayReservationSystem;
select * from Reservations; 
select * from Trains;
select * from Passengers;

truncate table Reservations;

	CREATE TABLE Reservations (

    ReservationId INT PRIMARY KEY IDENTITY(1,1),

    PassengerID INT FOREIGN KEY REFERENCES Passengers(PassengerID),

    TrainId INT FOREIGN KEY REFERENCES Trains(TrainId),

    PassengerName NVARCHAR(100) NOT NULL,

    Gender NVARCHAR(10) NOT NULL,

    Age INT NOT NULL,

	CreditNo INT, 

	BankName VARCHAR(40), 

	Quota VARCHAR(20),

    PNR NVARCHAR(20) NOT NULL UNIQUE,

    ReservationDate DATETIME NOT NULL,

    TicketStatus NVARCHAR(20) NOT NULL 
	Username

);


use RailwayReservationSystem;
truncate table Reservations;

Alter TABLE Reservations 
Username NVARCHAR(50),    

Password NVARCHAR(50);

UPDATE Trains
SET 
    ArrivalTime = DATEADD(DAY, DATEDIFF(DAY, ArrivalTime, GETDATE()), ArrivalTime),
    DepartureTime = DATEADD(DAY, DATEDIFF(DAY, DepartureTime, GETDATE()), DepartureTime);

	Create table Admin (AdminId int ,  Password varchar(30));
	insert into Admin Values(2, 'Password');
 delete from Admin where AdminId=2;