CREATE Database RailwayDB;
use RailwayDB;
CREATE TABLE Passengers(
PassengerId int Primary key Identity(1,1),
	Name varchar(100),
	Age int,
	Address varchar(20),
	Gender varchar(20),
	username varchar(300),
	password varchar(300)
	);

	create table Trains
(
	TrainId int Primary key Identity,
	TrainName nvarchar(100),
	Source nvarchar(100),
	Destination nvarchar(200),
	DepartureTime Datetime,
	ArrivalTime DateTime,
	Fare decimal(10,2)
);
 use RailwayDB
create table Reservation(
	ReservationId int Primary key Identity(1,1),
	PassengerId int foreign key References Passengers(PassengerId),
	TrainId int foreign key References Trains(TrainId),
	Class nvarchar(50),
	Quota nvarchar(50),
	PNR nvarchar(20),
	ReservationDate Datetime,
 Status nvarchar(50) check(Status IN('Reserved','Cancelled')),
 Fare Decimal(10,2)
	);
use RailwayDB;
drop table Reservation;

use RailwayDB;

use RailwayDB;
create table Reservation(
	ReservationId int Primary key Identity(1,1),
	PassengerId int foreign key References Passengers(PassengerId),
	TrainId int foreign key References Trains(TrainId),
	Class nvarchar(50),
	Quota nvarchar(50),
	PNR nvarchar(20),
	ReservationDate Datetime,
 TicketStatus nvarchar(50) check(TicketStatus IN('Reserved','Cancelled')),
 
	);

