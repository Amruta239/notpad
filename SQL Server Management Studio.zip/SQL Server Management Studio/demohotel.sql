use Demo;


CREATE TABLE Staff (
    staff_id INT PRIMARY KEY IDENTITY(1,1),
    name VARCHAR(100),
    age INT,
    address TEXT,
    nic VARCHAR(20),
    salary DECIMAL(10, 2),
    designation VARCHAR(50),
    email VARCHAR(100)
);

CREATE TABLE [User] (
    user_id INT PRIMARY KEY IDENTITY(1,1),
    username VARCHAR(50) UNIQUE,
    password VARCHAR(255),
    role VARCHAR(20) CHECK (role IN ('Owner', 'Manager', 'Receptionist')),
    staff_id INT,  -- Foreign key to Staff table for association
    FOREIGN KEY (staff_id) REFERENCES Staff(staff_id)
);

CREATE TABLE Guest (
    guest_id INT PRIMARY KEY IDENTITY(1,1),
    name VARCHAR(100),
    email VARCHAR(100),
    gender VARCHAR(10) CHECK (gender IN ('Male', 'Female', 'Other')),
    address TEXT,
    phone_number VARCHAR(15),
    member_code VARCHAR(20)  -- Unique membership code for guest
);

CREATE TABLE Room (
    room_id INT PRIMARY KEY IDENTITY(1,1),
    room_type VARCHAR(50),
    status VARCHAR(20) CHECK (status IN ('Available', 'Occupied')),
    price_per_night DECIMAL(10, 2),
    capacity INT,  -- max number of people
    description TEXT
);

CREATE TABLE Reservation (
    reservation_id INT PRIMARY KEY IDENTITY(1,1),
    guest_id INT,
    room_id INT,
    check_in_date DATE,
    check_out_date DATE,
    num_adults INT,
    num_children INT,
    status VARCHAR(20) CHECK (status IN ('Confirmed', 'Cancelled')),
    num_nights INT,
    FOREIGN KEY (guest_id) REFERENCES Guest(guest_id),
    FOREIGN KEY (room_id) REFERENCES Room(room_id)
);

CREATE TABLE Payment (
    payment_id INT PRIMARY KEY IDENTITY(1,1),
    reservation_id INT,
    total_amount DECIMAL(10, 2),
    payment_time DATETIME,
    credit_card_details VARCHAR(255),
    FOREIGN KEY (reservation_id) REFERENCES Reservation(reservation_id)
);
CREATE TABLE Bill (
    bill_id INT PRIMARY KEY IDENTITY(1,1),
    reservation_id INT,
    billing_date DATE,
    price DECIMAL(10, 2),
    taxes DECIMAL(10, 2),
    services DECIMAL(10, 2),
    total_amount DECIMAL(10, 2),
    FOREIGN KEY (reservation_id) REFERENCES Reservation(reservation_id)
);
CREATE TABLE Rate (
    rate_id INT PRIMARY KEY IDENTITY(1,1),
    room_id INT,
    check_in_date DATE,
    check_out_date DATE,
    num_guests INT,
    per_night_charge DECIMAL(10, 2),
    total_charge DECIMAL(10, 2),
    FOREIGN KEY (room_id) REFERENCES Room(room_id)
);
CREATE TABLE Inventory (
    inventory_id INT PRIMARY KEY IDENTITY(1,1),
    item_name VARCHAR(100),
    quantity INT,
    price_per_unit DECIMAL(10, 2)
);
CREATE TABLE Report (
    report_id INT PRIMARY KEY IDENTITY(1,1),
    report_type VARCHAR(50) CHECK (report_type IN ('Staff payment', 'Income')),
    generated_date DATE,
    content TEXT  -- Store content of the report as text or BLOB
);


----dot
CREATE VIEW ReservationDTO AS
SELECT
    r.reservation_id,
    g.name AS guest_name,
    r.check_in_date,
    r.check_out_date,
    r.num_adults,
    r.num_children,
    ro.room_type,
    r.status AS reservation_status,
    p.total_amount AS payment_amount
FROM Reservation r
JOIN Guest g ON r.guest_id = g.guest_id
JOIN Room ro ON r.room_id = ro.room_id
JOIN Payment p ON r.reservation_id = p.reservation_id;

CREATE VIEW BillDTO AS
SELECT
    b.bill_id,
    r.reservation_id,
    b.billing_date,
    b.price,
    b.taxes,
    b.services,
    b.total_amount
FROM Bill b
JOIN Reservation r ON b.reservation_id = r.reservation_id;


CREATE VIEW StaffDTO AS
SELECT
    s.staff_id,
    s.name AS staff_name,
    s.designation,
    s.salary
FROM Staff s;

